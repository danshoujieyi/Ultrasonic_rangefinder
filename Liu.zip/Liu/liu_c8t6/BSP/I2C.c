#include "I2C.h"

// 定义引脚
#define SDA_PIN	GPIO_PIN_9
#define SCL_PIN GPIO_PIN_8
#define I2C_PORT GPIOA

// 设置引脚高电平和低电平的宏定义
#define SDA_High HAL_GPIO_WritePin(I2C_PORT, SDA_PIN, GPIO_PIN_SET)
#define SDA_Low  HAL_GPIO_WritePin(I2C_PORT, SDA_PIN, GPIO_PIN_RESET)
#define SCL_High HAL_GPIO_WritePin(I2C_PORT, SCL_PIN, GPIO_PIN_SET)
#define SCL_Low  HAL_GPIO_WritePin(I2C_PORT, SCL_PIN, GPIO_PIN_RESET)

void SDA_OUT(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    GPIO_InitStruct.Pin = SDA_PIN; // 使用新的宏定义
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP; // 推挽输出
    GPIO_InitStruct.Pull = GPIO_NOPULL; // 不上拉
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH; // 高速
    HAL_GPIO_Init(I2C_PORT, &GPIO_InitStruct);
}

void SDA_IN(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    GPIO_InitStruct.Pin = SDA_PIN; // 使用新的宏定义
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT; // 输入模式
    GPIO_InitStruct.Pull = GPIO_PULLUP; // 上拉
    HAL_GPIO_Init(I2C_PORT, &GPIO_InitStruct);
}

// 初始化IIC
void I2C_Initation(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    // 使能GPIOB时钟
    __HAL_RCC_GPIOB_CLK_ENABLE();

    // 配置SDA和SCL引脚
    GPIO_InitStruct.Pin = SDA_PIN | SCL_PIN; // 使用新的宏定义
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP; // 推挽输出
    GPIO_InitStruct.Pull = GPIO_NOPULL; // 不上拉
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH; // 高速
    HAL_GPIO_Init(I2C_PORT, &GPIO_InitStruct);

    // PB6, PB7 输出高
    HAL_GPIO_WritePin(I2C_PORT, SDA_PIN | SCL_PIN, GPIO_PIN_SET);
}

//IIC起始信号
void I2C_Start(void)
{
	SDA_OUT();     	//SDA设置为输出
	SDA_High;	
	SCL_High;
    Delay_us(4);
	SDA_Low;		//START:当SCL为高电平时候，SCL拉低 
    Delay_us(4);
	SCL_Low;		//准备发送或接收 
}

//IIC结束信号
void I2C_Stop(void)
{
	SDA_OUT();		//SDA配置为输出
	SDA_Low; 		//STOP：当SCL为低电平时候，SDA由低变为高
    Delay_us(4);
	SCL_High;
    Delay_us(4);
	SDA_High;		//发送IIC结束信号
    Delay_us(4);
}

uint8_t I2C_Write_Ack(void)
{
    uint8_t TimeAck = RESET;
    SDA_IN(); // 配置 SDA 为输入
    SCL_High; // 设置 SCL 为高
    Delay_us(2); // 适当的延迟，保持不变

    while (HAL_GPIO_ReadPin(I2C_PORT, SDA_PIN) == GPIO_PIN_SET) // 读取 SDA 引脚状态
    {
        if (++TimeAck > 250)
        {
            I2C_Stop();
            return 1; // 超时，返回 1
        }
    }

    SCL_Low; // 设置 SCL 为低
    Delay_us(2); // 适当的延迟，保持不变
    return 0; // 确认成功，返回 0
}

// ack=0时, 不产生ACK应答, ack=1时候,产生ACK应答	
void I2C_Is_Ack(uint8_t ack)
{
	SCL_Low;
	SDA_OUT();
	if(ack)
		SDA_Low;	
	else
		SDA_High;
    Delay_us(2);
	SCL_High;
    Delay_us(2);
	SCL_Low;
}
					 				     
//IIC发送一位数据
void I2C_Send_Byte(uint8_t txd)
{                        
    SDA_OUT(); 	    
	SCL_Low;		//拉低时钟开始传输
    for(uint8_t t=0;t<8;t++)
    {              
		if((txd&0x80)>>7)
			SDA_High;
		else
			SDA_Low;
		txd<<=1;
        Delay_us(2);
		SCL_High;
        Delay_us(2);
		SCL_Low;
        Delay_us(2);
    }	 
} 


//读一位数据，ack=1时，发送ACK，ack=0，发送nACK   
uint8_t I2C_Read_Byte(unsigned char ack)
{
	unsigned char i,receive=0;
	SDA_IN();	//SDA设置为输入
    for(i=0;i<8;i++ )
	{
		SCL_High;
        Delay_us(2);
        receive<<=1;
        if(READ_SDA)receive++;   
		SCL_Low;
        Delay_us(1);
    } 
	
    if (!ack)
		I2C_Is_Ack(0);
    else
		I2C_Is_Ack(1);	
    return receive;
}


//读取一位数据
uint8_t I2C_Read_Data(void)
{
    uint8_t Data = RESET;
	SDA_IN();		
	for(uint8_t i=0;i<8;i++)
	{
		SCL_High;
		Delay_us(2);
		Data <<= 1;

        if (HAL_GPIO_ReadPin(I2C_PORT, SDA_PIN) == GPIO_PIN_SET) // 使用 HAL 函数
		{
			Data |= 0x01;
		}
		
		SCL_Low;
        Delay_us(2);
	}	
	return Data;
}

