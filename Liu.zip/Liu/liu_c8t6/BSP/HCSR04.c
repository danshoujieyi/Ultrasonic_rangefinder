#include "HCSR04.h"
#include "Delay_us.h"
unsigned char msHcCount = 0;//ms计数
float sound_speed = 0; // 声速 331.45 m/s
extern float temperature;
extern float humidity;
// 温湿度补偿参数
extern float temperature_compensation;
extern float humidity_compensation;

// 超声波初始化
void Ultrasonic_Init(void)
{
    // 使能GPIOB和定时器1的时钟
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_TIM1_CLK_ENABLE();

    GPIO_InitTypeDef GPIO_InitStruct = {0};

    // 配置TRIG引脚为推挽输出
    GPIO_InitStruct.Pin = GPIO_TRIG;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(PORT_SR04, &GPIO_InitStruct);
    HAL_GPIO_WritePin(PORT_SR04, GPIO_TRIG, GPIO_PIN_RESET);

    // 配置ECHO引脚为上拉输入
    GPIO_InitStruct.Pin = GPIO_ECHO;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(PORT_SR04, &GPIO_InitStruct);

    // 初始化定时器1
    htim1.Instance = TIM1;
    htim1.Init.Prescaler = 72 - 1; // 设置预分频器，72MHz主时钟 -> 10kHz
    htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim1.Init.Period = 1000 - 1;      // 设置周期为1000（1ms）
    htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    htim1.Init.RepetitionCounter = 0; // 高级定时器的重复计数器设置为0
    htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
    HAL_TIM_Base_Init(&htim1);

    // 清除定时器计数和中断标志
    __HAL_TIM_SET_COUNTER(&htim1, 0);
    __HAL_TIM_CLEAR_FLAG(&htim1, TIM_FLAG_UPDATE);

    // 开启定时器中断
    HAL_TIM_Base_Start_IT(&htim1);
}


void Open_Timer(void)
{
    __HAL_TIM_SET_COUNTER(&htim1, 0); // 清除定时器计数

    msHcCount = 0;

    HAL_TIM_Base_Start_IT(&htim1);   // 使能定时器
}

uint32_t Get_TIMER_Count(void)
{
    uint32_t time = 0;
    time = msHcCount * 1000;                   // 得到us
    time += __HAL_TIM_GET_COUNTER(&htim1);     // 得到ms

    __HAL_TIM_SET_COUNTER(&htim1, 0);          // 清除定时器计数
    HAL_Delay(10);
    return time;
}


void Close_Timer(void)
{
    HAL_TIM_Base_Stop_IT(&htim1);  // 关闭定时器
}


// 距离
float Hcsr04GetLength(void)
{
    /*测5次数据计算一次平均值*/
    float length = 0;
    float t = 0;
    float sum = 0;
    unsigned int  i = 0;
    while(i != 10)
    {

        SR04_TRIG(1);//trig拉高信号，发出高电平
        Delay_us(20);//持续时间超过10us
        SR04_TRIG(0);//trig拉低信号，发出低电平
        /*Echo发出信号 等待回响信号*/
        /*输入方波后，模块会自动发射8个40KHz的声波，与此同时回波引脚（echo）端的电平会由0变为1；
        （此时应该启动定时器计时）；当超声波返回被模块接收到时，回波引 脚端的电平会由1变为0；
        （此时应该停止定时器计数），定时器记下的这个时间即为
                                        超声波由发射到返回的总时长；*/

        while(SR04_ECHO() ==  GPIO_PIN_RESET);//echo等待回响

        Open_Timer();   //打开定时器

        i++;

        while(SR04_ECHO() == GPIO_PIN_SET);

        Close_Timer();   // 关闭定时器

        t = Get_TIMER_Count();   // 获取时间,分辨率为1us
        length = (float)t / 58.0f;   // cm
        sum += length;
    }
    length = sum/10;//五次平均值
    return length;
}

// 距离补偿
float Hcsr04GetLength_offset(void)
{
    /*测5次数据计算一次平均值*/
    float length_new = 0;
    float t = 0;
    float sum_new = 0;
    unsigned int  i = 0;
    while(i != 10)
    {

        SR04_TRIG(1);//trig拉高信号，发出高电平
        Delay_us(20);//持续时间超过10us
        SR04_TRIG(0);//trig拉低信号，发出低电平
        /*Echo发出信号 等待回响信号*/
        /*输入方波后，模块会自动发射8个40KHz的声波，与此同时回波引脚（echo）端的电平会由0变为1；
        （此时应该启动定时器计时）；当超声波返回被模块接收到时，回波引 脚端的电平会由1变为0；
        （此时应该停止定时器计数），定时器记下的这个时间即为
                                        超声波由发射到返回的总时长；*/

        while(SR04_ECHO() ==  GPIO_PIN_RESET);//echo等待回响

        Open_Timer();   //打开定时器

        i++;

        while(SR04_ECHO() == GPIO_PIN_SET);

        Close_Timer();   // 关闭定时器

        t = Get_TIMER_Count();   // 获取时间,分辨率为1us，超声波来回时间

        // 温湿度补偿
        sound_speed = 331.45 + 0.606 * temperature + 0.0124 * humidity;
        length_new = sound_speed*t*100/(1000000*2); // cm
        sum_new += length_new;
    }
    length_new = sum_new/10;//五次平均值
    return length_new;
}


