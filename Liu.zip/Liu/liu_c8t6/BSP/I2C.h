#ifndef __I2C_H
#define __I2C_H

#include "stm32f1xx_hal.h"
#include "Delay_us.h"
#include "stdio.h"

#define READ_SDA   HAL_GPIO_ReadPin(I2C_PORT, SDA_PIN)  // 输入 SDA

void SDA_IN(void);
void SDA_OUT(void);


void I2C_Initation(void);           //初始化IIC的IO口				 
void I2C_Start(void);				//發送IIC開始信號
void I2C_Stop(void);	  			//發送IIC停止信號
void I2C_Send_Byte(uint8_t txd);			//IIC sends a byte
void I2C_Is_Ack(uint8_t ack);			// ack=0時,不發送ACK應答, ack=1時,發送ACK應答
void IIC_Write_One_Byte(uint8_t daddr,uint8_t addr,uint8_t data);
uint8_t I2C_Read_Data(void);
uint8_t I2C_Write_Ack(void);
uint8_t I2C_Read_Byte(unsigned char ack); //IIC reads a byte
uint8_t IIC_Read_One_Byte(uint8_t daddr,uint8_t addr);
// uint8_t IIC_Wait_Ack(void); 				//IIC waits for ACK signal
#endif
